<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Gestion Réservations</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 50px auto; background-color: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
        h1 { color: #333; margin-bottom: 40px; }
        .button-group { display: flex; flex-direction: column; gap: 20px; }
        .btn { padding: 15px 30px; font-size: 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; transition: background-color 0.3s ease; }
        .btn-client { background-color: #3498db; color: white; }
        .btn-client:hover { background-color: #2980b9; }
        .btn-reservation { background-color: #27ae60; color: white; }
        .btn-reservation:hover { background-color: #229954; }
        footer { text-align: center; margin-top: 40px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenue dans l'application de gestion</h1>
        <div class="button-group">
            <a href="creerClient" class="btn btn-client">Ajouter un Client</a>
            <a href="creerReservation" class="btn btn-reservation">Ajouter une Réservation</a>
        </div>
    </div>
    <footer>
        <p>Application de gestion des réservations © 2026</p>
    </footer>
</body>
</html>