<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ajouter une Réservation</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 500px; margin: 30px auto; background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #333; margin-bottom: 30px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; color: #555; font-weight: bold; }
        input[type="text"], input[type="email"], input[type="tel"], input[type="number"], select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; box-sizing: border-box; }
        input:focus, select:focus { outline: none; border-color: #3498db; box-shadow: 0 0 5px rgba(52, 152, 219, 0.3); }
        .btn { width: 100%; padding: 12px; background-color: #27ae60; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; transition: background-color 0.3s ease; }
        .btn:hover { background-color: #229954; }
        .alert { padding: 10px; margin-bottom: 20px; border-radius: 4px; text-align: center; }
        .alert-error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .space-label { background-color: #e8f4f8; padding: 10px; margin-bottom: 20px; border-radius: 4px; color: #333; }
        footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Ajouter une réservation :</h2>
        
        <% if(request.getAttribute("erreur") != null) { %>
            <div class="alert alert-error">
                <%= request.getAttribute("erreur") %>
            </div>
        <% } %>

        <div class="space-label">Espace réservation</div>

        <form action="creerReservation" method="POST">
            <div class="form-group">
                <label for="nom">Nom</label>
                <input type="text" id="nom" name="nom" required>
            </div>
            
            <div class="form-group">
                <label for="prenom">Prénom</label>
                <input type="text" id="prenom" name="prenom" required>
            </div>
            
            <div class="form-group">
                <label for="telephone">Téléphone</label>
                <input type="tel" id="telephone" name="telephone" required>
            </div>
            
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label for="type">Type</label>
                <select id="type" name="type" required>
                    <option value="">-- Sélectionner un type --</option>
                    <option value="chambre-single">Chambre Single</option>
                    <option value="chambre-double">Chambre Double</option>
                    <option value="suite">Suite</option>
                    <option value="deluxe">Deluxe</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="prix">Prix</label>
                <input type="number" id="prix" name="prix" step="0.01" required>
            </div>

            <div class="form-group">
                <label for="vue">Vue</label>
                <select id="vue" name="vue" required>
                    <option value="">-- Sélectionner une vue --</option>
                    <option value="piscine">Piscine</option>
                    <option value="mer">Mer</option>
                    <option value="montagne">Montagne</option>
                    <option value="ville">Ville</option>
                </select>
            </div>
            
            <button type="submit" class="btn">Ajouter Réservation</button>
        </form>
    </div>

    <footer>
        <p>Application de gestion des réservations © 2026</p>
    </footer>
</body>
</html>