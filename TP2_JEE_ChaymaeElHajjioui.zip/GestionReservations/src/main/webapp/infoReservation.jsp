<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.example.Reservation" %>
<%@ page import="com.example.Client" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Informations Réservation</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 30px auto; background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #27ae60; margin-bottom: 30px; }
        h3 { color: #333; margin-top: 30px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        table th { background-color: #34495e; color: white; padding: 12px; text-align: left; font-weight: bold; }
        table td { padding: 12px; border-bottom: 1px solid #ddd; }
        table tr:hover { background-color: #f9f9f9; }
        .btn { padding: 10px 20px; background-color: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; transition: background-color 0.3s ease; }
        .btn:hover { background-color: #2980b9; }
        .btn-container { text-align: center; margin-top: 30px; }
        .success-message { background-color: #d4edda; color: #155724; padding: 12px; border-radius: 4px; margin-bottom: 20px; text-align: center; border: 1px solid #c3e6cb; }
        footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-message">
            Réservation ajoutée avec succès
        </div>

        <h2>Affichage des données de la réservation :</h2>

        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Téléphone</th>
                    <th>E-mail</th>
                    <th>Type</th>
                    <th>Prix</th>
                    <th>Vue</th>
                </tr>
            </thead>
            <tbody>
                <% 
                    Reservation currentReservation = (Reservation) session.getAttribute("currentReservation");
                    if(currentReservation != null) {
                        Client client = currentReservation.getClient();
                %>
                <tr>
                    <td><%= client.getNom() %></td>
                    <td><%= client.getPrenom() %></td>
                    <td><%= client.getTelephone() %></td>
                    <td><%= client.getEmail() %></td>
                    <td><%= currentReservation.getType() %></td>
                    <td><%= String.format("%.2f", currentReservation.getPrix()) %></td>
                    <td><%= currentReservation.getVue() %></td>
                </tr>
                <% 
                    } else {
                %>
                <tr>
                    <td colspan="7" style="text-align:center;">Aucune réservation n'a été ajoutée</td>
                </tr>
                <% } %>
            </tbody>
        </table>

        <h3>Toutes les réservations :</h3>

        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Téléphone</th>
                    <th>E-mail</th>
                    <th>Type</th>
                    <th>Prix</th>
                    <th>Vue</th>
                </tr>
            </thead>
            <tbody>
                <% 
                    List<Reservation> reservations = (List<Reservation>) session.getAttribute("reservations");
                    if(reservations != null && !reservations.isEmpty()) {
                        for(Reservation reservation : reservations) {
                            Client c = reservation.getClient();
                %>
                <tr>
                    <td><%= c.getNom() %></td>
                    <td><%= c.getPrenom() %></td>
                    <td><%= c.getTelephone() %></td>
                    <td><%= c.getEmail() %></td>
                    <td><%= reservation.getType() %></td>
                    <td><%= String.format("%.2f", reservation.getPrix()) %></td>
                    <td><%= reservation.getVue() %></td>
                </tr>
                <% 
                        }
                    } else {
                %>
                <tr>
                    <td colspan="7" style="text-align:center;">Aucune réservation enregistrée</td>
                </tr>
                <% } %>
            </tbody>
        </table>

        <div class="btn-container">
            <a href="index.jsp" class="btn">Retourne au formulaire d'ajout</a>
        </div>
    </div>

    <footer>
        <p>Application de gestion des réservations © 2026</p>
    </footer>
</body>
</html>