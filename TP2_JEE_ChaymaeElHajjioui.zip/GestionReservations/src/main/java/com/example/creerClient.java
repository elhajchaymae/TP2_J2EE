package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/creerClient")
public class creerClient extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/Inscription.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String telephone = request.getParameter("telephone");
        String email = request.getParameter("email");

        if (nom == null || nom.isEmpty() || 
            prenom == null || prenom.isEmpty() || 
            telephone == null || telephone.isEmpty() || 
            email == null || email.isEmpty()) {
            
            request.setAttribute("erreur", "Tous les champs sont obligatoires!");
            request.getRequestDispatcher("/Inscription.jsp").forward(request, response);
            return;
        }

        Client client = new Client(nom, prenom, telephone, email);

        HttpSession session = request.getSession();
        List<Client> clients = (List<Client>) session.getAttribute("clients");
        if (clients == null) {
            clients = new ArrayList<>();
        }
        clients.add(client);
        session.setAttribute("clients", clients);
        session.setAttribute("currentClient", client);

        request.getRequestDispatcher("/infoClient.jsp").forward(request, response);
    }
}






