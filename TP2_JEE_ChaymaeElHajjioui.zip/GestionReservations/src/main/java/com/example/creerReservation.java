package com.example;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/creerReservation")
public class creerReservation extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/Reservation.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String telephone = request.getParameter("telephone");
        String email = request.getParameter("email");
        String type = request.getParameter("type");
        String prixStr = request.getParameter("prix");
        String vue = request.getParameter("vue");

        if (nom == null || nom.isEmpty() || 
            prenom == null || prenom.isEmpty() || 
            telephone == null || telephone.isEmpty() || 
            email == null || email.isEmpty() ||
            type == null || type.isEmpty() ||
            prixStr == null || prixStr.isEmpty() ||
            vue == null || vue.isEmpty()) {
            
            request.setAttribute("erreur", "Tous les champs sont obligatoires!");
            request.getRequestDispatcher("/Reservation.jsp").forward(request, response);
            return;
        }

        try {
            double prix = Double.parseDouble(prixStr);
            Client client = new Client(nom, prenom, telephone, email);
            Reservation reservation = new Reservation(client, type, prix, vue);

            HttpSession session = request.getSession();
            List<Reservation> reservations = (List<Reservation>) session.getAttribute("reservations");
            if (reservations == null) {
                reservations = new ArrayList<>();
            }
            reservations.add(reservation);
            session.setAttribute("reservations", reservations);
            session.setAttribute("currentReservation", reservation);

            request.getRequestDispatcher("/infoReservation.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            request.setAttribute("erreur", "Le prix doit être un nombre valide!");
            request.getRequestDispatcher("/Reservation.jsp").forward(request, response);
        }
    }
}
